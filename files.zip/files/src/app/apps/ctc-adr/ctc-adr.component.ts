import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ctc-adr',
  templateUrl: './ctc-adr.component.html',
  styleUrls: ['./ctc-adr.component.scss']
})
export class CtcAdrComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
