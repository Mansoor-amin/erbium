import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manage-entities',
  templateUrl: './manage-entities.component.html',
  styleUrls: ['./manage-entities.component.scss']
})
export class ManageEntitiesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
