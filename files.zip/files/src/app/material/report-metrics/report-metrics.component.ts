import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-report-metrics',
  templateUrl: './report-metrics.component.html',
  styleUrls: ['./report-metrics.component.scss']
})
export class ReportMetricsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
